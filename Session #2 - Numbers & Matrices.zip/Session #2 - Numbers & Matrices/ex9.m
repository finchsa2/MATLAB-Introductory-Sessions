%ex9

%More on Matrices

%In ex6, we covered some basic mathematical operations for numbers. You can
%do similar things with matrices, which is useful as it allows you to do a
%whole bunch of calculations in a single line of code.

%Make two matrices to play around with...
disp('Here is a random matrix called "A":');
A = rand(3,4);
disp(A);

disp('Here is another one called "B":');
B = rand(3,4);
disp(B);

%Addition & Subtraction
%What does it mean to add and subtract two /groups/ of numbers? We simply
%do the operation for each element location.

disp('So then, A + B is...');
addAB = A + B; %addC(1,1) = A(1,1) + B(1,1), subC(2,1) = A(2,1) + B(2,1),...
disp(addAB);

disp('And A - B is...');
subAB = A - B; %subC(1,1) = A(1,1) - B(1,1), subC(2,1) = A(2,1) - B(2,1),...
disp(subAB);

%As we are doing it element by element, you might guess that A and B have
%to have the same dimensions! Otherwise we might get to an element location
%in A that doesn't exist in B, or vice versa, and get very stuck.

