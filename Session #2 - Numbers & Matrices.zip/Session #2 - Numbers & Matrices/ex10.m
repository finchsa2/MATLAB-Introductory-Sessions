%ex10

%Matrix Multiplication

%I've prepared some notes on the "standard" way to multiply matrices, which
%you can find in the G: drive. 

disp('Matrix number one is:');
A = rand(3,5); %Three rows, four columns.
disp(A);

disp('Matrix number two is:');
B = rand(5,2); %Five rows, two columns.
disp(B);

%When multiplying two matrices, the number of rows in the first matrix must
%be equal to the number of columns in the second. To multiply, we use the
%standard * symbol.

disp('And multiplying them together, we get:');
C = A*B;
disp(C);