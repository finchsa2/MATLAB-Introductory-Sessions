%ex8

%More on Matrices

disp('Here is a row of numbers:');
A = [1,5,3];
disp(A);

%We were able to stick together strings by seperating them with commas and
%enclosing them within square brackets. If you do this with numbers, you
%can stick the numbers together into a matrix. The above example forms a
%single row of 3 numbers.

disp('Here is a column:');
B = [1;2;5];
disp(B);

%What about if you want to make a single column instead? Something very
%similar, only now you seperate the numbers by semi-colons rather than
%commas. So the semi-colon can do something other than hide the code's
%execution from the command prompt!

disp('Another column:');
C = [1,8,4]';
disp(C);

%Check out what C looks like in the Workspace window. Even though we
%seperated the numbers with commas like we did for A, C is a column and not
%a row. We added the single quote mark ' at the end of the matrix, which
%"flips" it.

disp('Going from 1 to 10...');
D = 1:10;
disp(D);

%Here is another way to make a matrix. We have set a start point "1", and
%an end point "10", seperated by the colon character. This colon tells
%MATLAB to count from 1 to 10, in increments of 1 (the default value).

disp('Ignoring the even numbers...');
D_Odd = 1:2:10;
disp(D_Odd);

%A "middle" number can be used to represent the increment size. Here we
%count in 2s, which means we go from 1, 3, 5... We never hit 10, the
%closest we can get is 9.

disp('Even numbers only, as a column:');
D_Even = 2:2:10;
disp(D_Even');

%We can of course change the starting or end points. I changed the starting
%point from 1 to 2, so it goes 2, 4, 6, 8, 10. 

disp('We can do more than integers! Count from 0.4 to 1.7 in increments of 0.1...');
E = 0.4:0.1:1.3;
disp(E);

%Counts from 0.4 to 1.3, in increments of 0.1... 

disp('We can make a 2D matrix...');
F = rand(5,3); %An example of a 2D matrix before flipping.
disp(F);

disp('...and flip it!');
F_flipped = F'; %An example of a 2D matrix after flipping.
disp(F_flipped);

%How do we make a 2D matrix from scratch?
disp('We can slap this row...');
OneRow = [3,8,5];
disp(OneRow);
disp('...and this row...');
TwoRow = [7,2,3];
disp(TwoRow);

disp('...together in the "downwards" direction with ; to make:');
G = [OneRow;TwoRow];
disp(G);

%When we made B, we seperated each number with a semi-colon. This stored
%the numbers in a column (going down) rather than in a row (going along).

%You can also slap together matrices in this way! In G, we have slapped two
%single rows together to form a matrix with two rows.

disp('Or we can slap them together in the "along" direction:');
H = [OneRow, TwoRow];
disp(H);

%We can add them together in the "along" direction to form a single, longer
%row.

disp('We can "flip" each one before adding too...');
disp('"Along" direction:');
I = [OneRow', TwoRow']; %We can add two columns in the "along" direction...
disp(I);
disp('"Downwards" direction:');
J = [OneRow'; TwoRow']; %...Or, add them in the "downwards" direction to form a single larger column!
disp(J);




