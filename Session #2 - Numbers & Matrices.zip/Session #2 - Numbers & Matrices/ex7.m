%ex7

%Some Basics on Matrices

%First of all... What exactly is a matrix?

%In previous examples we covered the cell array, which is kind of like a
%mini Excel sheet. Within the cell array, you can store various things
%within each cell: Numbers, Strings, and even other cell arrays.

%In terms of MATLAB, a matrix is like a specific kind of cell array. You
%still can store things within each cell, but now there are some restrictions:

%1: You can only store numbers.
%2: Matrices can still be 1D, 2D, 3D... But they have to be perfect lines,
%rectangles, cuboids... So, you cannot have a gap in the middle of a
%matrix, or a bit poking out of the side of one.

%Why bother with the matrix at all if the cell array does the same thing
%and more? The restrictions applied to the matrix allow us to do some very
%useful mathematical operations.

%Let's make a matrix.
disp('Here is a randomised matrix:');
RandomMatrix = rand(3,5);
disp(RandomMatrix);

%The "rand" function spits out a matrix. The input values to rand are
%integers. Here, I've input 3 and 5, which spits out a matrix which has 3
%rows and 5 columns. You can check this out in the Workspace window. You can increase the number of integers you input into
%rand, which increases the number of dimensions of its output matrix. This
%is actually very simple, but you can impress people if you say that you can work with 11
%dimensional matrices...

%For "rand", each element of the matrix is a randomly generated value
%between 0 and 1. There are some other functions very similar to rand that
%spit out matrices with different values, such as:

disp('And here is a matrix consisting of ones:');
OneMatrix = ones(4,1); %Every element = 1
disp(OneMatrix);

disp('This matrix is nothing but zeroes');
ZeroMatrix = zeros(2,4); %Every element = 0
disp(ZeroMatrix);