%ex11

%Matrix Operations "element by element"

%How do we take two matrices of the same size, and do a sort of
%element-by-element multiplication? So we multiply the first elements
%together, the second elements together, etc...

disp('The first matrix is:');
A = [[1,2,3];[1,2,3]];
disp(A);

disp('And the second matrix is:');
B = [[1,1,1];[2,2,2]];
disp(B);

disp('Multiply them elementally, we get:');
C = A.*B; %Note the . character before * this time.
disp(C);

%Adding the . sign tells MATLAB to do things element by element. We can
%apply this to all sorts of operations. The stipulation is that the two
%matrices must be the same size.

disp('Divide them elementally, and we get:');
D = A./B; 
disp(D);

