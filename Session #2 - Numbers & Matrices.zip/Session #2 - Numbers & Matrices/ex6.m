%ex6

%Some Basics on Numbers

%So far we've looked more or less exclusively at strings. Of equal
%importance are numbers, as we are obviously interested in using MATLAB for
%data processing tasks.

A = 5; %We assign numeric values to variables in a similar fashion to strings.
B = 3; %Note here that we don't require the quotation marks. We can just type in the number.

%When we have a number and want to use it like a string, it's good practice
%to use the command "num2str". As you might have guessed, this stands for
%number-to-string... functions should normally have pretty clear names.

%Displaying some numbers like a string...
disp(num2str(A));
disp(num2str(B));
disp([num2str(A),num2str(B)]);

%Some Basic Operations
disp(num2str(A + B)); %Addition uses +
disp(num2str(A - B)); %Subtraction uses -
disp(num2str(A * B)); %Multiplication uses *
disp(num2str(A / B)); %Division uses / (Note: NOT the backslash "\"!)
disp(num2str(A ^ B)); %To The Power Of (Exponent) uses ^

%Or, to use a fancy formatted string from a previous exercise...
MathString = 'When we do %d %s %d, we get %d.';

disp(sprintf(MathString, A, 'plus', B, A + B));
disp(sprintf(MathString, A, 'to the power of', B, A ^ B));
disp(sprintf(MathString, 9, 'divided by', 0, 9 / 0));