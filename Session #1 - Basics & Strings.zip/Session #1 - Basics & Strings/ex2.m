%ex2

%Some Basics on Strings

%We can use the disp function to display a string in the command window. 

disp('Hello there!'); %With disp, we can enter a string directly.

JustSomeString = 'Hello again.'; %Or assign a variable, and stick that variable into disp.
disp(JustSomeString);

%What if we'd like to slap some strings together?
A = 'I am getting ';
B = 'pretty tired of ';
C = 'saying hello all the ';
D = 'time.';

disp([A, B, C, D]); %You can add strings together using square brackets, and seperating each variable with a comma.

MuchLongerString = [A,B,C,D]; %We can create a variable in the same way.
disp(MuchLongerString);

disp(['I am getting ', 'pretty tired of ', 'saying hello all the ', 'time.']) %We didn't need to make A, B, C and D for this. 

%Your Workspace window might be beginning to look kind of full at this
%point. If you like, you can right click and select "Clear Workspace".