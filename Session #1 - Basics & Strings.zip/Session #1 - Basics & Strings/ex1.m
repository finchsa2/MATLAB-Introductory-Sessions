%ex1

%Some Basics on Strings

%In MATLAB, comments are recognised by putting the % sign in front of
%things. A comment is something which doesn't interact with the code
%whatsoever, and is used for notation only. Otherwise, code can be very
%difficult to follow.

JustSomeString = 'Hello World' %Here we've created the variable JustSomeString.
AnotherString = 'Hello Again'; %Another variable. I've ended with the semi-colon character ; this time.

%What did the semi-colon do? It suppresses the operation in the command
%window. So if you look there, you'll see JustSomeString being created, but not AnotherString.
%But both will be visible in the Workspace window. In general, you'll want
%to end all lines with the semi-colon.