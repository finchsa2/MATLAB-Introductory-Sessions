%ex4

%Some Basics on Strings

%So far, we have been assigning strings directly in the code, by typing
%stuff like MyString = 'blahblahblah';

%We can also get user input to make things a bit more dynamic, by using the
%"input" function.

SomeInput = input('Type something here:','s');

%Here, we have a function that requires two strings. Note that the strings
%have NOT been conjoined by the comma symbol, as they are not enclosed by
%square brackets. They are two seperate things being fed into the function.

%The first string is a sort of prompt, indicating to the user that they
%need to enter something into the Command window. It could be anything,
%really. Try out using a different string here and see what happens.

%The second input is kind of weird, it's just the 's' character. This is
%telling MATLAB to convert whatever the user types into a string. Or to put
%it another way, MATLAB puts ' on either side of what you typed in and runs
%with it.

%We can display the user's input back to them using something like this:
disp(['Thanks! You typed in: "', SomeInput, '"']);

%Let's apply a bit of what we covered in the previous examples. We can split
%up the user's input, and display to them the first and last word of what
%they typed.

SomeSplitInput = strsplit(SomeInput); %Break up the input
disp(['The first word you typed was: "', SomeSplitInput{1},'"']); %Display the first string in the SomeSplitInput cell array.
disp(['The last word you typed was: "', SomeSplitInput{end},'"']); %Display the "end" string in the SomeSplitInput cell array.

%Before I mentioned that to get a part of a cell array, you need to enter
%its location as an integer. The exception to this rule is by typing "end",
%which returns the last member of the array. This is very handy if we don't
%know in advance how big the array is going to be, like if it's based on
%user input. We could also type "end - 1" if we wanted to get the
%second-to-last word.