%ex3

%Some Basics on Strings

%We can split them into smaller parts, by breaking them at each
%"delimeter" using the strsplit function.

BunchOfStrings = strsplit('Break This Apart');

%Here, we are breaking apart a string at every "space" character.

%BunchOfStrings is a collection of strings stored in a thing called a
%"cell array". Open it up in the Workspace window and you'll see something
%looking like an Excel sheet, where each cell contains a word. What we
%actually did was break apart that big string at every space character (the "delimeter").

%Type "help strsplit" (without quotations!) into the MATLAB Command Window
%to see how strsplit works. It's possible to break apart strings using
%something other than the space character.

%Cells allow us to store multiple things inside the same
%variable. So if I have, say, 10 different strings, I can store them all
%within a single cell array rather than making a seperate variable for each
%one (like with A, B, C and D in the earlier example). It's not very useful
%at this stage, but for bigger operations it's a lifesaver.

%We can display different bits of the cell array we just created as follows:

disp(BunchOfStrings{1});
disp(BunchOfStrings{2});
disp(BunchOfStrings{3});

%If you have BunchOfStrings open in the Workspace window, you'll see that
%each of the numbers I entered corresponds to where that substring is in
%the cell array. We can read out a particular part of the BunchOfStrings
%array by enclosing the location (1, 2 or 3 in this case) with curly
%brackets {}.

%We could piece them back together again in a different order if we wanted
%to:

disp([BunchOfStrings{1},' ',BunchOfStrings{3},' ',BunchOfStrings{2}]);

%In this case, I added some spaces between the words using ' '

%We've used three different kinds of brackets already, so to summarise:

%Regular Brackets: Use these to determine the input of a function, like strsplit(blahblah)
%Square Brackets: Use these to slap things together, like a bunch of strings [str1, str2, str3]
%Curly Brackets: These are mostly used for cells. If it's curly, it's probably a cell.