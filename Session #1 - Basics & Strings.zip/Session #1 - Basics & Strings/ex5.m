%ex5

%Some Basics on Strings

%So we know how to combine strings, and sandwich variables into strings.
%But there can be more elegant ways to handle this sometimes. For instance,
%what if I want to use what is basically the same string over and over again 
%but with subtle variations?

%Check this guy out:
LunchString = 'Hello, my name is %s and I like to eat %s.';

%You can sort of tell what this is. %s sounds like it means "BLANK", where
%you keep that sentence but fill in the blanks with something. To fill in
%those blanks, we use the sprintf function.

BananaString = sprintf(LunchString,'Carla','bananas');

%The first input into sprintf is your formatted string containing the %s
%characters. Additional arguments are you filling up the blanks. We can 
%display these as follows to see what's happening:

disp(BananaString);

%Of course we can input into disp more directly:

disp(sprintf(LunchString,'Eva','onions'));

%Do you see an orange squiggly line under disp there? This means MATLAB is
%telling you that there's an easier way to code what you just typed in. In
%this case, there's actually a function that combines disp with sprintf
%that we can use called fprintf. It's kind of weird though, so I'm skipping
%it for now.

%The %s means fill up the blank with a string. What about numbers? We can
%use the %d character instead.

AnotherFormatString = 'Howdy, my name is %s and I like to eat %d %s a day.';
disp(sprintf(AnotherFormatString,'Sam',67,'meals'));