%ex28

%Now that we know how to find files of a particular kind in a folder, and
%also how to mine through the contents of a file (or at least, a text
%file), we can combine the two together into some kind of generic file
%importer script.

%There's nothing new in the below code, I'm just tying up all the pieces
%together.

%Everything will be stored in this master variable.
AllFileData = cell(0);

%Define some initial variables.
RequiredString = 'banana'; %The file name must contain "banana"
RequiredFormat = '.txt'; %The file name must contain ".txt"
Delimiter = ';'; %We want to break rows up by this delimiter
ValidFileNumber = 0; %Remember before when we specified LineNumber? Same deal here.

%Same as before: Select a folder, get contents...
SelectedFolder = uigetdir;
FolderContents = dir(SelectedFolder);

%Loop through the files...
for a = 1:size(FolderContents,1); %Loop through each structure in FolderContents
    FileName = FolderContents(a).name; %Get the file name string using the "name" key.
    
    %Now we design some booleans to qualify the file.
    FormatOK = ~isempty(strfind(FileName,RequiredFormat)); %Does ".txt" appear in the file name?
    StringOK = ~isempty(strfind(FileName,RequiredString)); %Does 'banana' appear in the file name?
    
    %Make an if statement to exclude files which don't meet our criteria.
    if and(FormatOK, StringOK); %If both of these are true, display the file name...
        
        %Specify some counting variables...
        ValidFileNumber = ValidFileNumber + 1; %A new file has been found...
        LineNumber = 0; %Reset the current line number
        DataDump = cell(0); %Reset the data dump
        
        %Open up the file
        FullFilePath = [SelectedFolder, '\', FileName]; %Remember, need to get the full path to feed into fopen...
        FileIdentifier = fopen(FullFilePath);
        
        while ~feof(FileIdentifier) %While NOT the end of the file...
            %First, update the line number.
            LineNumber = LineNumber + 1;
            
            %Then we get the next line, and break apart as before.
            CurrentLine = fgetl(FileIdentifier); %Rather than outright display this string, we set it equal to a variable instead.
            SubStrings = strsplit(CurrentLine, Delimiter); %Break apart this line by the ; character.
            
            %Now we will loop through each sub-string and write to the cell.
            for a = 1:size(SubStrings,2);
                
                S = SubStrings{a}; %S is one of the elements of "SubStrings".
                S_Num = str2double(S); %S_Num is what we get when attempting to convert S into a number.
                
                if isnan(S_Num); %If converting to a number resulted in nonsense, then S is something other than a number.
                    DataDump{LineNumber,a} = S; %Write the original string to the cell if not a number.
                else
                    DataDump{LineNumber,a} = S_Num; %If it does convert to a number properly, write this instead.
                end
                
            end
            
        end
        
        %Close the file...
        fclose(FileIdentifier);
        
        %How will we store the contents? We can make our own structure array.
        AllFileData{ValidFileNumber} = struct;
        AllFileData{ValidFileNumber}.FileName = FileName;
        AllFileData{ValidFileNumber}.Data = DataDump;
        
    end
    
end