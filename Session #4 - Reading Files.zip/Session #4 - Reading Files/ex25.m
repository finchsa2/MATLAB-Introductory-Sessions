%ex25

%There are actually a whole load of ways you can read data from a text
%file, and fgetl is among the slowest. One of the appeals of mining
%line-by-line is that you have all the flexibility you need. Some functions
%import super quickly, but make assumptions like all elements being numbers
%or each row having the same amount of elements (i.e. like a matrix).

%I want to demonstrate this by giving you an absolutely horrible file where
%the format is all messed up. Open up "Oh My God.txt" to see what I mean.
%The rows contain both strings and numbers, and each row has a different
%number of elements. Some end with the delimiter and others don't. If you
%threw one of those convenient functions at this, it would fail miserably.
%Most files you import won't be as bad as this of course, but you might
%occasionally be dealing with files containing weird blips, particularly if
%you are trouble-shooting corrupt files.

%All of the stuff we pull from this file will end up in DataDump. This will
%be a cell array, rather than a matrix. The advantage of the cell array is
%that it stores numbers, and can have uneven distributions of elements.

DataDump = cell(0);

%We will also want to track the line number this time. It's not really
%obvious at this point why I'm doing this, and it's something I've added
%retrspectively. But it's going to be important for writing to particular
%locations within the cell array.

LineNumber = 0; %We will add to this as we go through the while loop.

%As always, open up a file...
[FileName, FileDirectory] = uigetfile('.txt'); 
FileIdentifier = fopen([FileDirectory,'\',FileName]); %Open up the file.

while ~feof(FileIdentifier) %While NOT the end of the file...
    %First, update the line number.
    LineNumber = LineNumber + 1;
    
    %Then we get the next line, and break apart as before.
    CurrentLine = fgetl(FileIdentifier); %Rather than outright display this string, we set it equal to a variable instead.
    SubStrings = strsplit(CurrentLine, Delimiter); %Break apart this line by the ; character.
    
    %Now we will loop through each sub-string and write to the cell.
    for a = 1:size(SubStrings,2);
        
        S = SubStrings{a}; %S is one of the elements of "SubStrings".
        S_Num = str2double(S); %S_Num is what we get when attempting to convert S into a number.
        
        if isnan(S_Num); %If converting to a number resulted in nonsense, then S is something other than a number.
            DataDump{LineNumber,a} = S; %Write the original string to the cell if not a number.
        else
            DataDump{LineNumber,a} = S_Num; %If it does convert to a number properly, write this instead.
        end
        
    end
    
end
disp(DataDump);
fclose(FileIdentifier); %And don't forget to close!!!