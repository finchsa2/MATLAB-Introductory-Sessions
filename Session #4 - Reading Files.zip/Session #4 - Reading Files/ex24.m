%ex24

%So now we can read lines from a file with an unspecified amount of lines.
%For data processing, we are probably going to want to read numbers from a
%file. Additionally, we will want to seperate out multiple numbers from a
%given line. Check out the example file "Bunch of Numbers.txt" to see what
%I mean.

%Let's specify the delimiter.
Delimiter = ';';
%What is a delimiter? We saw it in the first session when using "strsplit".
%It's used to mark break points in a line. So the string '2;3;5;7' could be
%broken up into sub-strings of '2', '3', '5' and '7' by using a delimiter
%of ';'. The comma is used frequently as a delimiter in the English
%language, whereas other languages prefer to use the semi-colon (as the
%comma is used for decimal places instead of the period character).

%We also want to store the numbers somewhere. So let's make a variable for
%this called NumberDump. This starts as an empty matrix, but we
%progressively add rows to it as we cycle through each line of the file.
NumberDump = [];

%As always, open up a file...
[FileName, FileDirectory] = uigetfile('.txt'); 
FileIdentifier = fopen([FileDirectory,'\',FileName]); %Open up the file.

while ~feof(FileIdentifier) %While NOT the end of the file...
    %First, let's get out the numbers stored in a line.
    CurrentLine = fgetl(FileIdentifier); %Rather than outright display this string, we set it equal to a variable instead.
    SubStrings = strsplit(CurrentLine, Delimiter); %Break apart this line by the ; character.
    SubNumbers = str2double(SubStrings); %We can convert each of these sub-strings into a number using str2double. This gives us a matrix.
    
    %Next, we want to add the row of numbers to NumberDump. We covered
    %adding matrices together in session #2, so review this if you're lost.
    NumberDump = [NumberDump; SubNumbers]; 
end

fclose(FileIdentifier); %Don't forget to close!

%Once we're done, we'll display NumberDump just because.
disp(NumberDump);

%If you do this, notice that the last column of NumberDump is a useless
%bunch of NaNs. This is simply because each line of the file ended with
%";", and strsplit will read the line as having an empty string on the
%right-side of the last ";". This empty string also gets fed into the
%str2double function, which returns a NaN.

%If you want to kill a column, you can do something like this:
disp('Or, without NaNs...');
NewNumberDump = NumberDump(:,1:(end-1));
disp(NewNumberDump);
