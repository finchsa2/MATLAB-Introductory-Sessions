%ex27

%Now that we know how to pull up the contents of a folder, we can be a bit
%more specific about what we are interested in. For instance, what if we
%are only interested in txt files? And what if we only want to import files
%of a certain name structure (such as only files with "banana" in the
%name)? We will do something similar to the previous example, but with
%additional restrictions embedded in the loop.

%Same as before: Select a folder, get contents...
SelectedFolder = uigetdir;
disp(['Folder Selected: ', SelectedFolder]);
FolderContents = dir(SelectedFolder);

disp('The text files containing "banana" in the name are:');
for a = 1:size(FolderContents,1); %Loop through each structure in FolderContents
    FileName = FolderContents(a).name; %Get the file name string using the "name" key.
    
    %Now we design some booleans to qualify the file.
    txtOK = ~isempty(strfind(FileName,'.txt')); %Does ".txt" appear in the file name?
    bananaOK = ~isempty(strfind(FileName,'banana')); %Does 'banana' appear in the file name?
    
    %Make an if statement to exclude files which don't meet our criteria.
    if and(txtOK, bananaOK); %If both of these are true, display the file name...
        disp(FileName);
    end
    
end