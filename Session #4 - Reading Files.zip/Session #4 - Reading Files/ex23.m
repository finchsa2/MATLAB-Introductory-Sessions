%ex23

%So, each time fgetl is called it skips ahead to the next line of the file.
%What we did in the previous example isn't very slick, because we had to
%know in advance that the file was 7 lines long. What if we don't know in
%advance? We can use the "feof" function (Find End Of File). This statement
%is false if we haven't mined to the last line.

%While we are at it, we can use a better way of grabbing a file. The
%"uigetfile" opens up a Windows dialogue for selecting a file. If you were
%wondering, there's also a "uigetdir" which lets you select a directory.
%More on that later.

[FileName, FileDirectory] = uigetfile; %Get the file location as a string.

%uigetfile returns multiple things. You can set multiple variables as outputs in
%sqaure brackets like above. If you were interested in only the first
%output, you would simply ignore the second output with "FileName =
%uigetfile" or "[FileName,~] = uigetfile" (where the ~ in this case is
%where you don't want to specify a variable for the output). If you wanted
%only the second output and not the first, then you would do [~,
%FileDirectory] = uigetfile.

%We feed in the entire file path into fopen, so we need to glue the two
%outputs together like so:
FileLocationString = [FileDirectory,'\',FileName]; %Add the two strings together for the full path.
FileIdentifier = fopen(FileLocationString); %Open up the file.

while ~feof(FileIdentifier) %While NOT the end of the file...
    disp(fgetl(FileIdentifier)); %Loop through the files...
end

fclose(FileIdentifier); %Don't forget to close!