function [ALLDATA] = Import_SPR_File(FilePath)
%SPRtest
%MATLAB is basically terrible at reading in unusual CSV files, so I've
%built a customised importer that can read all information stored in a
%standard SPR file. The Data Loader file is tricky because information under
%a header can have different column lengths. OUTPUT is a structure split into
%cells according to the headers in the file.

%Last update: 3 Oct 2014
%Sam Fincham

    delimiter = ';';

    fid=fopen(FilePath);
    [~,FileName,~] = fileparts(FilePath);
    
    ALLDATA = struct;
    ALLDATA.Type = 'SPR';
    ALLDATA.FileName = FileName;

    while ~feof(fid) %While the end of the file hasn't been reached...
    
        % Define and reset these parameters every time data under a header is
        % found. The value [] is an empty matrix/cell.
        
        DATA = cell(0);
    
        % Gets the first line of a CSV file. When next called, it reads in the next
        % line. Once the end of the CSV file is reached, fgetl returns -1.
        strip = fgetl(fid);
    
        % If a line is not empty, check to see if it's a header.
        if ~isempty(strip);
        
            if strcmp(strip(1),'['); %Finding a header. The first char is [.
            
                %Remove odd characters so header can be used as a struct name.
                strip(or(strip == delimiter, strip == '-')) = [];
                strip(or(strip == '[',strip == ']')) = [];
                HEADER = strip; %HEADER is the string name of the header.
            
            end
        
            % Now to gather data found under header. Keep finding lines until a
            % blank line is reached, or until the end of the file is reached.
            
            while and(~isempty(strip),~feof(fid)); 
                
                strip = fgetl(fid); %strip is the next line of the file.
                DATA{end+1,1} = strip; %Write strip to DATA cell.
                
            end
            
            %Data has been read in, but needs to be organised and converted into a useful format.
            DATA = regexp(DATA,delimiter,'split'); % Split the string by its delimiter
            maxDATA = max(cellfun(@(x) numel(x),DATA)); % Safeguard against strings with different column lengths
            DATA = cellfun(@(x) [x, cell(1,maxDATA - length(x))],DATA,'UniformOutput',false); %Fixes input so all cells can be concatated
            DATA = vertcat(DATA{1:end,1}); %Organises data into single cell
            
            if strcmpi(HEADER,'MeasurementData'); %If measurement data, convert to double here.
                
                DATA = str2double(DATA(4:end,1:356)); %Strip out useless axis data and first few text rows. Unfortunately, this is slow! Can I process directly from a cell, I wonder?
                %DATA = DATA(DATA(:,2) == 0,:);
                
                MainCartData = NaN(175,1600,3);
                MainCartData_mpd = NaN(175,1600,3);
                
                Dry3CartData = NaN(175,20,3);
                Dry3CartData_mpd = NaN(175,20,3);
                
                for spot = 1:3;
                    
                    SpotData = DATA(DATA(:,5) == (spot-1),:);
                    
                    MCD = reshape(SpotData((SpotData(:,2) == 0),7:181)',175,numel(SpotData((SpotData(:,2) == 0),7:181))/175);
                    MainCartData(:,1:size(MCD,2),spot) = MCD;
                    
                    MCD_mpd = reshape(SpotData((SpotData(:,2) == 0),182:356)',175,numel(SpotData((SpotData(:,2) == 0),182:356))/175);
                    MainCartData_mpd(:,1:size(MCD_mpd,2),spot) = MCD_mpd;
                    
                    D3D = reshape(SpotData((SpotData(:,2) == 3),7:181)',175,numel(SpotData((SpotData(:,2) == 3),7:181))/175);
                    Dry3CartData(:,1:size(D3D,2),spot) = D3D;
                    
                    D3D_mpd = reshape(SpotData((SpotData(:,2) == 3),182:356)',175,numel(SpotData((SpotData(:,2) == 3),182:356))/175);
                    Dry3CartData_mpd(:,1:size(D3D_mpd,2),spot) = D3D_mpd;
                    
                end
                
                ALLDATA.CartData = struct;
                ALLDATA.CartData.Main = MainCartData;
                ALLDATA.CartData.Dry3 = Dry3CartData;
                ALLDATA.CartData.Main_MPD = MainCartData_mpd;
                ALLDATA.CartData.Dry3_MPD = Dry3CartData_mpd;
                
            else
            
            % eval just performs the function written in the string. So here all that's being done is writing the structure OUTPUT.HEADER.
            eval(['ALLDATA.' HEADER ' = DATA;']);
            end
        
        end
        
    end
    % Close file
    fclose(fid);

end

