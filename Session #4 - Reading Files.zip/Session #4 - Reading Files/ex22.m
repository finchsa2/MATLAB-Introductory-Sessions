%ex22

%So far, we have covered the basics of strings, numbers and booleans. We
%have learned how to build simple sequences using "if", "while" and "for"
%loops. Now we can take this foundational knowledge and explore some more
%advanced operations.

%Each of the sessions I want to cover in future will focus on a particular
%project. The first project we will tackle is reading data from text and
%Excel files. If you want to be using MATLAB to grind through big data
%sets, this is a pretty important thing to know. In doing so, we will also
%be covering some other foundational things like "structures" and
%"functions" which we haven't had a chance to play with yet.

%Here we can define the location of a file. There are more clever ways of
%doing this, but for now we can be sloppy and enter the string directly.

FileLocationString = 'G:\BusUnits\Vivacta\All Users\MATLAB CoE\Session #4 - Reading Files\Example Dump\Vogon Poetry.txt';

%Next we want to somehow open this text file. We can do this with "fopen".
%When we use this function, MATLAB will open the file.

FileIdentifier = fopen(FileLocationString);

%"FileIdentifier" is an integer which is sort of tagged to the file we just
%opened. If we want to screw around with the file, we will be using
%FileIdentifier to target it. You can have multiple files open at a time,
%if you want. In this case there would be a different file identifier for
%each file you opened.

%So once we have opened a file, what do we do with it? To read individual
%lines of a text file, you could use the "fgetl" function which reads the
%first line, and then the second, third, fourth, etc. each time it is
%called.

%Like so:
disp(fgetl(FileIdentifier));
disp(fgetl(FileIdentifier));
disp(fgetl(FileIdentifier));
disp(fgetl(FileIdentifier));
disp(fgetl(FileIdentifier));
disp(fgetl(FileIdentifier));
disp(fgetl(FileIdentifier));

%We close a file using "fclose". In general, you want to close a file once
%you're done with it. If you have too many open at the same time, MATLAB's
%going to start lagging.

fclose(FileIdentifier);
