%ex26

%The stuff we have covered allows you to read data in pretty much any way
%from a text file, so long as you cram in enough fudge factors while looping
%through the lines. You could do other things too if you wanted to, like
%stopping after a certain number of lines or ignoring some lines altogether.

%So far, we have imported files individually. The next step is to import a
%group of files together. To do this, we need to find a way to select a
%directory, and THEN find a way to list all files in the directory we wish
%to import. To complicate things further, the directory has sub-folders and
%will inevitably contain files we want to ignore.

%To start with, let's go over two new functions: "uigetdir", which lets us
%select a directory, and "dir", which lists the contents of a directory.

SelectedFolder = uigetdir;
disp(['Folder Selected: ', SelectedFolder]); %Just some user feedback
FolderContents = dir(SelectedFolder);

%FolderContents contains these new things called "structures". In the cell
%arrays and matrices we covered before, the elements are tagged by a
%certain location (the nth row, and the mth column). In structures, each
%"thing" is tagged by a word. It's like a dictionary or encyclopedia in a
%way, where the tag is the word and the definition is the data you're
%trying to pull out of it. A structure can have a bunch of different things
%stored within it: Matrices, strings, cell arrays, and even other
%structures.

%FolderContents is a structure ARRAY, where each element of the array is a
%structure. So you would be asking "What is inside the structure located at
%row N, column M?" if you wanted to dig data out of a structure array.

%If the things inside a structure are tagged by words or "keys" instead of
%locations, how do you get them? By typing in NameOfStructure.KeyName. So
%if I had a structure named "Fruit" and a thing tagged to a key called
%"Banana", I would type in Fruit.Banana.

%So, each structure in FolderContents contains information on each
%sub-folder or file found within the selected folder. This information
%includes the name, size, and format of the item. If we were only
%interested in the names, we could summon them using the "name" key.

disp('The stuff inside the folder is:');
for a = 1:size(FolderContents,1); %Loop through each structure in FolderContents
    FileName = FolderContents(a).name; %Get the file name string using the "name" key.
    disp(FileName);
end

%As an aside, you might notice that the first and second items found are
%called "." and ".." respectively. I have no idea why, and it's just a
%quirk of the dir function I guess. Just ignore these. You could start the
%"for" loop at 3 rather than 1 to skip them entirely.

