%ex15

%The last thing I want to cover about booleans is the concept of a logic
%gate. It's like taking multiple booleans and forming some grand truth out
%of them. They are really simple, but crucial for building even basic
%functions.

%Don't worry too much about commiting everything below to memory. It's a
%sort of "learn as you mess about with it" kind of thing.

%The first logic gate is "and". It works like this: If A and B are true,
%then true. Otherwise, false.

and_true_true = and(true,true); %This is "true".
and_true_false = and(true,false); %This is "false".
and_false_true = and(false,true); %This is "false".
and_false_false = and(false,false); %This is "false".

%So with "and", you're kinda checking if both of your input conditions are
%true. If you need both to be true, but one (or both) of them is FALSE,
%then the "and" statement returns a false in kind.

%The other guy we need to talk about is "or", which is kind of like a
%complacent version of "and". Only one of the input conditions for an "or"
%needs to be true, although you could have both.

or_true_true = or(true, true); %This is "true"
or_true_false = or(true, false); %This is "true".
or_false_true = or(false, true); %This is "true".
or_false_false = or(false, false); %This is "false".

%An offshoot of "or" is "xor", otherwise known as "exclusive or". Here the
%two inputs have to be different, so only one of the two can be true.
%True-true or false-false returns false.

xor_true_true = xor(true, true); %This is "false".
xor_true_false = xor(true, false); %This is "true".
xor_false_true = xor(false, true); %This is "true".
xor_false_false = xor(false, false); %This is "false".

%If there's an input condition you need that is not represented by any of
%the above, you can wrangle things with the "not" operator which is
%represented by "~" (see earlier examples). For instance:

%I want false-false to be true, otherwise false.
notand_true_true = ~and(true, true); %false
notand_true_false = ~and(true, false); %false
notand_false_true = ~and(false, true); %false
notand_false_false = ~and(false, false); %true

%I want true-true and false-false to be true, otherwise false.
xor_nottrue_true = xor(~true, true); %true
xor_nottrue_false = xor(~true, false); %false
xor_notfalse_true = xor(~false, true); %false
xor_notfalse_false = xor(~false, false); %true