%ex20

%The last sort of loop we need to cover is the "for" loop. Unlike while
%loops and if statements, "for" is not dependent on any kind of truth
%statement. Instead, it repeats a chunk of code again and again while
%working its way through some kind of list.

%Here is a for loop that repeats itself while changing the value of "a".
DeclareString = 'The current number is %d.';
MathString = 'The square of %d is %d, and the square root of %d is %d.';

for a = 1:10; %We repeat the chunk of code when a = 1, then a = 2, ... up to a = 10.
    disp('...');
    disp(sprintf(DeclareString,a));
    disp(sprintf(MathString, a, a^2, a, a^0.5)); %We repeat this string, changing up the value of "a".
end %As usual, we need to "end" the loop.