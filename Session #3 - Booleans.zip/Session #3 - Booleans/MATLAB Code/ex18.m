%ex18

%The "if" statement executes a chunk of code depending on if a condition is
%true or false. The "while" loop acts a bit differently: It continues to
%execute a chunk of code so long as a condition remains true. And if that
%condition changes to false, the while loop ends.

%Note: While loops can be DANGEROUS! If the condition never reaches
%"false", it will execute infinitely. If your while loop runs rampant with
%no hope of stopping, type "ctrl-c" to kill it off.

%Set some initial conditions...
RiddleSolved = false; %As long as the riddle is unsolved, this is false.
UserQuit = false; %As long as the user has not typed "quit", this is false.

%Display a groovy riddle.
disp('Answer my riddle! *ahem*');
disp('~ I am the part of the bird that is not in the sky ~');
disp('~ I can swim through the ocean, yet still remain dry ~');
disp('What am I? (Enter "QUIT" to give up)');

%Here's the meat of the while loop. %While RiddleSolved AND UserQuit are
%FALSE (note the "~"), the while loop keeps going.
while and(~RiddleSolved, ~UserQuit); 
    UserInput = input('> ','s'); %Ask for an input each time we loop
    if strcmpi(UserInput,'shadow'); %Correct answer. No cheating!
        RiddleSolved = true;
    elseif strcmpi(UserInput,'quit'); %User gives up.
        UserQuit = true;
    else %User typed in the wrong answer.
        disp('Incorrect! Try again.');
    end
end

%This is reached once the while loop ends.
if RiddleSolved; %If it ended because the user found the correct answer
    disp('Congratulations! That is the correct answer!');
else %Otherwise, the user got here by quitting.
    disp('Give up? The answer is "shadow"!');
end