%Paella

%Set some initial variables
Cook = false; %True if it is time to cook...
Ingredients = cell(0); %Contents of paella

%Introduction
disp('Welcome to Paella Simulator 2000!');
disp('This Is Your One Stop Shop For Cooking Paella');

%Start Loop
while ~Cook
   disp('Do you wish to ADD an ingredient, COOK, or SCRAP the paella?');
   UserInput = input('> ','s');
   
   %Code for adding ingredients...
   if strcmpi(UserInput, 'ADD');
       disp('What would you like to add?');
       Ingredients{end + 1} = input('> ','s');
       disp('The paella currently contains:');
       for a = 1:numel(Ingredients);
           disp(Ingredients{a});
       end
   end
   
   %Code for scrapping everything and starting afresh
   if strcmpi(UserInput,'SCRAP');
       disp('You threw away everything to start again!');
       Ingredients = cell(0);
   end
   
   %Code for cooking
   if strcmpi(UserInput,'COOK');
       disp('You are ready to cook! Here we go...');
       Cook = true;
   end
end

%Calculate score
if numel(Ingredients) < 3; %If not many ingredients, user never gets a good score.
    score = 1;
else %Determine a result completely randomly ;)
    score = round(4*rand + 2); %This will return an integer between 2 and 6. Think about it...
end

%Display result
disp('You are cooking a paella with:');
for a = 1:numel(Ingredients);
    disp(Ingredients{a});
end
disp('And the result is...');
quality = {'LACKLUSTRE','AMAZING','GROSS','SAGGY','LUMPY','MINTY'};
disp(quality{score});