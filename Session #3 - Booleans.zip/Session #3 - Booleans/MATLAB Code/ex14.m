%ex14

%Another way to create a boolean is to compare strings. There are quite a
%few ways of doing this.

%Declare two strings... the same, but one uses caps.
BananaString = 'bananas are great';
BananaStringEnthusiastic = 'BANANAS ARE GREAT';

%Declare another two strings... identical to one another.
RaisinString = 'raisins are gross'; %Disclaimer: I love raisins. If you dont then you are a bad person.
RaisinStringRepeat = RaisinString;

%This operation treats each string sort of like a matrix, where each
%element is a character in the string. 
CompareCharacters = BananaString == RaisinString;
%The result will be a logical matrix, where an
%element is true if the characters match and false if they do not. This
%operation is probably not very useful.

%Compare two whole strings - Are they the same?
CompareBananas = strcmp(BananaString, BananaStringEnthusiastic); %String Compare
CompareRaisins = strcmp(RaisinString, RaisinStringRepeat);
%The "strcmp" command compares two strings precisely. If the two match
%entirely, like the raisin strings, then the result is true. If the two
%differ even slightly like the banana strings, the result is false.

%Compare strings with and without capitals
CompareBananasWithCaps = strcmpi(BananaString, BananaStringEnthusiastic);
%Using "strcmpi" rather than "strcmp" does exactly the same thing, but it's
%not case sensitive.

%Find a string within another string
FindBananaGreatness = strfind(BananaString, 'great');
FindRaisinGreatness = strfind(RaisinString, 'great');
%Does the word 'great' live in any of these strings? It lives in the
%BananaString, but not the RaisinString. The result of the 'strfind'
%function is NOT a boolean, but a number indicating where the search string
%first appears.

%Find a string within another string - boolean output
AreBananasGreat = ~isempty(FindBananaGreatness);
AreRaisinsGreat = ~isempty(FindRaisinGreatness);