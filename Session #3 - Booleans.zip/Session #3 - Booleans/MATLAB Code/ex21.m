%ex21

%For loops can be a bit more elaborate if we want them to be. For instance,
%sometimes we will want the loop to repeat itself a variable amount of
%times rather than being fixed (like with the limit of 10 repeats in the
%previous example).

%Here is another example, which calls on a bunch of different things we
%have not seen yet. The user selects a folder, and then the code repeats
%via a for loop all the files it can find within that folder.

%First, some boring display stuff.
disp('I am going to find a bunch of files for you!');
disp('First, give me a folder to work with...');
WorkingFolder = uigetdir('','Select a folder!'); %User navigates towards a folder.
FolderContents = dir(WorkingFolder); %The "dir" command gets the contents of an input folder (files & sub-folders).

%Make a string that displays for each item found in the folder.
ItemString = 'I found a %s called %s which was created on %s.';

%FolderContents is cell array, where the cells contain these things called
%"structures". Each "structure" contains details on a file or sub-folder
%found in the directory. Why do I start with 3 rather than 1? The first
%two cells of FolderContents are full of nonsense due to the way the "dir"
%command works. Weird, I know...

for a = 3:size(FolderContents,1); %We are looping through each element of FolderContents. From 3 to how "big" it is (the "size").
    
    %Let us get some details for this value of "a".
    ItemName = FolderContents(a).name;
    DirStatus = FolderContents(a).isdir;
    CreationDate = FolderContents(a).date;
    
    %Display some juicy details!
    if DirStatus; %If the item is a sub-folder...
        disp(sprintf(ItemString,'folder',ItemName,CreationDate));
    else %If it is a file...
        disp(sprintf(ItemString,'file',ItemName,CreationDate));
    end
    
end