%ex13

%The last data type to cover is the "boolean". This is the simplest of all data types,
%and in fact can only have two values: True or False, 1 or 0. But... You
%can do a LOT with it.

%There are basically two ways to make a boolean. The first is to simply
%declare a variable being equal to true or false.

T = true;
F = false;

%Note that these are NOT strings, as we have not applied the quotation
%marks on either side of "true" and "false". If you open up these variables
%in the command window, you will see that T and F are "logical" 1x1
%matrices containing 1 and 0 respectively.

%We can flip things around and turn true into false, and false into true,
%using the '~' character. The '~' means "not". So "not true" is false, and
%"not false" is true.

NotT = ~T;
NotF = ~F;

%A more interesting way to create a boolean is via some kind of truth
%statement, whose answer can be either true or false. Truth statements form
%the heart of programming and are very important and interesting (you'll
%have to take my word on that last claim).

%Does a number fit a particular definition? Often shortcut definition functions are
%labled as "issomething". For example:

APrimeCalculation = isprime(3); %Is 3 a prime number? Yep...
AnInfinite = isinf(9); %Is 9 infinite? Nope...
AScrewUp = isnan(nan); %Did you screw up your calculation and end up with a non-applicable number? Probably...

%To compare two variables exactly, the "==" sign is used. The truth statement "A ==
%B" is asking "Is A completely equal to B?". The result of this truth
%statement is ALWAYS either true or false.

%Comparing single numbers...

BrillMath = (6 == 2*3); %Is 1 (logical), as 6 is equal to 2 x 3.
BadMath = (7 == 4*2); %Is 0 (logical), as 7 is NOT equal to 4 x 2.

%We can do operations on numbers before comparing. 
KindaEqual = (round(6.453) == round(5.983)); %Are these the same when rounded?
MagnitudeOnly = (abs(-2.455) == abs(2.455)); %Are they the same when ignoring the sign?

%Comparing matrices is to compare each individual element. As usual, the
%matrices must be of the same dimensions in order for this comparison to
%work, as you're comparing element by element. The result of such a
%comparison is a matrix of booleans!

SomeNumbers = [5,6,3,4];
SomeMoreNumbers = [5,2,1,4];
SomeTruthMatrix = C == D;
SomeSizeComparison = (numel(SomeNumbers) == numel(SomeMoreNumbers)); %"numel" means number of elements in a matrix.

%These operations have been "exactly equal to" operations. We can do
%inequalities as well.

Inequality = (7 > 5); %Less-than and greater-than statements.
InequalityMore = (2 <= 5); %You can say "<=" or ">=" for "less-than or equal to".
InequalityAndThenSome = (SomeNumbers < SomeMoreNumbers); %You can do the same for whole matrices to speed things up.





