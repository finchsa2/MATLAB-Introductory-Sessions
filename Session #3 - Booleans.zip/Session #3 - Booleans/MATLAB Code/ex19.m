%ex19

%Here is another while loop, this time using some numbers and if
%statements. We will ask the user for an input, and get the code to count
%upwards to it. We will also throw in some error checks in case the user
%does something stupid like type in something that is not a number!

%First we get the user input
disp('Give me a number, and I will show you how to count to it.');
UserNumber = input('> ','s');
UserNumber = str2double(UserNumber); %Convert the input from a string to a number

if isnan(UserNumber) %If not a number...
    disp('That is NOT a number!');
    disp('Try again...');
    ex19 %Repeat the code.
else %If this is a number, we are good to go.
    if UserNumber > 100; %We do not want the number to be too high, otherwise we will be here for a long time.
        disp('Errrrr... That is WAY too high! I will be here forever.');
        disp('Try something smaller!');
        ex19; %Repeat code.
    elseif UserNumber < 5; %Dont do too small, no point.
        disp('Really? Give me something a little higher...');
        ex19 %Repeat code.
    else
        CurrentNumber = 1; %This is the number that is displayed when the code counts upwards.
        disp('Ready? Here we go...');
        while CurrentNumber < UserNumber; %While the counting number is less than the user input...
            disp([num2str(CurrentNumber),'...']); %Display the counting number
            CurrentNumber = CurrentNumber + 1; %And then each time we loop, the counting number goes up by 1.
        end
        disp([num2str(CurrentNumber), '!!!!']); %We reach this once CurrentNumber is equal to UserNumber.
        disp(['That is how you count to ', num2str(UserNumber),'!']);
    end
end