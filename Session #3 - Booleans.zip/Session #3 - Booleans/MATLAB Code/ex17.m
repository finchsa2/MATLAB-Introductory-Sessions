%ex17

%Some more "if" statements. See if you can work out what's going on here.

%Introduction...
disp('There is an aligator in the room, and it is blocking the DOOR.');
disp('You are armed with a PENCIL, and a stick of GUM. There is one WINDOW in the room.');
disp('You have one chance to escape. What will you do!?');

%Prompt...
UserInput = input('> ','s');
UpperCaseInput = upper(UserInput);
disp('');

%Decisions...
if strfind(UpperCaseInput,'DOOR');
    disp('You head straight for the DOOR. You attempt to jump over the aligator, but it just bites your legs off.');
    disp('GAME OVER.');
elseif strfind(UpperCaseInput,'PENCIL');
    disp('With a keen aim, you throw the PENCIL and hit the aligator straight in the eye! This just pisses it off though.');
    disp('GAME OVER.');
elseif strfind(UpperCaseInput,'GUM');
    disp('You distract the gator with some vanilla & raspberry gum. Its jaws get stuck together, and you make your escape!');
    disp('YOU WIN!!!!!');
elseif strfind(UpperCaseInput, 'WINDOW');
    disp('You jump out of the window. Unfornutely, there is a pack of bears out there waiting for you.');
    disp('GAME OVER.');
else
    disp('You stumble around in confusion. The aligator eats you.');
    disp('GAME OVER.');
end

%Play again?
disp('');
disp('Play again? Y/N');
UserDecision = input('> ','s');
if strcmpi(UserDecision, 'Y');
    disp('');
    ex17; %What does this do?
end