%ex16

%Now that I have bored you to death with strings, numbers and booleans, we
%can FINALLY move onto the more interesting and practical stuff!

%Before, we talked about qualifying statements as either true or false. But
%what really can we do with that? We can use booleans to execute specific
%chunks of code. So if something is true, execute THAT chunk, otherwise,
%execute the OTHER chunk instead.

%Here's an example. We'll ask the user to type in a number, and reprimand
%them if they type in something other than a number.

%First, ask for an input. We covered this in earlier examples.
UserInput = input('Type me a number: ','s'); %Ask the user to type in a number.

%To check if the input is a number, we first need to convert the input
%froma string to a number. The "str2double" function does this. If it can't
%get a number from the input, like if the user typed in "banana", then the
%result is the non-applicable number "nan".
InputAsNumber = str2double(UserInput); %Convert the user's input into numeric form.

%So if the converted input is "nan", the user didn't do as they were told.
%We can use the "isnan" function to check this. If the numeric form is a
%"nan", then the if-statement is activated and the chunk of code is
%executed.

if isnan(InputAsNumber); %If the input is not a number...
    disp('That is not a number, you dolt.'); %If answer is nan, execute this chunk.
else %Otherwise...
    disp(['Thanks! You typed in: ', UserInput]); %If answer is NOT a nan, Execute this chunk.
end %Any time we start an "if", we have to have an "end".